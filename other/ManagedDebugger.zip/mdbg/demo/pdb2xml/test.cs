using System;

class MyTest
{
static void Main()
{
	int myLocal = 5;
	Console.WriteLine("Hi");
	Console.WriteLine("Value:" + myLocal);
}
}
