//---------------------------------------------------------------------
//  This file is part of the CLR Managed Debugger (mdbg) Sample.
// 
//  Copyright (C) Microsoft Corporation.  All rights reserved.
//---------------------------------------------------------------------

ReadMe.txt for enc project.

This is a loadable extension.  Type "load enc" in mdbg to get this functionality.

It allows you to edit your code mid-run and continue without needing to restart the debugging session.
This feature is new to the CLR in this release.  Give it a try and see what you think.
In this form, it is a bit hard to use, but when integrated into a full IDE, it should be pretty cool.
